# Hospital_Management_System
I developed this app using spring boot 
