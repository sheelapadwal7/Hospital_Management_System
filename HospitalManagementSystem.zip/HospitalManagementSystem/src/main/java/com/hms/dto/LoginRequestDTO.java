package com.hms.dto;

import lombok.Data;

@Data
public class LoginRequestDTO {
	
	private String userName;
	
	private String password;
	
	private Integer id;
	
	
}
