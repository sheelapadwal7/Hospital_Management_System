package com.hms.dto;

import lombok.Data;

@Data
public class InventoryDTO {

    private Integer id;

    private String itemName;

    private int quantity;

    
}

