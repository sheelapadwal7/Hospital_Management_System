package com.hms.enums;

/**
 * 
 * 
 @author DURGESH */
public enum LinkType{
	ADMIN,
	DOCTOR,
	RECEPTIONIST
}
