package com.hms.enums;

public enum Role {
    USER,
    ADMIN
}
