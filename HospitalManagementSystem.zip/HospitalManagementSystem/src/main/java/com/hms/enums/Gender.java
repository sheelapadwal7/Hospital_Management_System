package com.hms.enums;

public enum Gender {
	MALE,FEMALE,TRANSGENDER


}
